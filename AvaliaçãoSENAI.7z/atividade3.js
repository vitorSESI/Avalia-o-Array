
let numeros = [87, 6, 99, 23, 12, ];
let soma = 0;

for (let i = 0; i < numeros.length; i++) {
    soma += numeros[i];
}
alert(`Os numeros na array são: ${numeros}.`)
alert(`A soma dos numeros é: ${soma}`)